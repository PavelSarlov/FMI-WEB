<?php

namespace CCS\Models\Entities;

abstract class User
{
    protected $userId       = null;
    protected $userName     = null;
    protected $userEmail    = null;
    protected $userPassword = null;
    protected $userRole     = null;
    protected $userIdentity = null;
}
