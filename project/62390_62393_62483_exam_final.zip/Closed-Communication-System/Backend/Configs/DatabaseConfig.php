<?php

define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'ccs_db');
define('DB_DIALECT', 'mysql');
define('DB_CHARSET', 'utf8');
