Съдържание на архива:
    .
    ├── 62393.pdf
    ├── 62393.pptx
    ├── 62393_README.txt
    ├── 62393_invite.png

Име: Павел Сарлов
ФН: 62393
Имейл: sarlovpavel@gmail.com
